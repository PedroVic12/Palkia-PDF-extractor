#!/usr/bin/env python3
"""
script_inicial_anaRede.py - Sistema Completo de Automação AnaREDE e Organon
Integrado com CLI Launcher usando Rich TUI

Autor: Pedro Victor
Versão: 2.0.0
Data: Janeiro 2026
"""

import sys
import os
import subprocess
import time
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, List, Dict, Tuple
import pyautogui
import pygame

try:
    from gtts import gTTS
except ImportError:
    print("⚠️  gtts não instalado. Função de voz desabilitada.")
    gTTS = None

try:
    from win10toast import ToastNotifier
    WINDOWS = True
except ImportError:
    WINDOWS = False
    print("⚠️  win10toast não disponível (apenas Windows)")

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.prompt import Prompt, Confirm
    from rich.table import Table
    from rich.style import Style
    from rich import box
    from rich.tree import Tree
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.live import Live
except ImportError:
    raise ImportError(
        "A biblioteca 'rich' é necessária. Instale com: pip install rich"
    )

console = Console()


# ============================================================================
# CLASSE CONFIGURACOES (Original mantida)
# ============================================================================
class Configuracoes:
    """Configurações originais do sistema"""
    
    def __init__(self):
        # Caminhos originais
        caminho_sav: str = r"C:\Users\pedrovictor.veras\OneDrive - Operador Nacional do Sistema Eletrico\Documentos\ESTAGIO_ONS_PVRV_2025\Casos - Cenarios - ONS - Real\SIN\Sav\3Q2025_estudo_v1.SAV"
        caminho_spt: str = r"C:\Users\pedrovictor.veras\OneDrive - Operador Nacional do Sistema Eletrico\Documentos\ESTAGIO_ONS_PVRV_2025\Casos - Cenarios - ONS - Real\SIN\diagramas\SIN.lst"
        
        # NOVA VARIÁVEL - Caminho dos decks
        self.caminho_decks_anaRede: str = r"C:\Users\pedrovictor.veras\OneDrive - Operador Nacional do Sistema Eletrico\Documentos\ESTAGIO_ONS_PVRV_2025\ONS + SIN + Tarefas PLC 2026\SIN"
        
        self.PROGRAMAS: list[str] = ["Explorador de arquivos", "Anarede 12", "Organon.exe"]
        
        self.arquivos_anaRede: dict[str, str] = {
            "caminho_sav": caminho_sav,
            "caminho_spt": caminho_spt,
            "caminho_decks": self.caminho_decks_anaRede,
        }
        
        # Create a ToastNotifier object
        self.toaster: ToastNotifier = ToastNotifier() if WINDOWS else None
    
    def showToast(self, title: str, message: str, icon_path: str = None, 
                   duration: int = 5, threaded: bool = True):
        """Mostra uma notificação na tela (Original)"""
        if not self.toaster:
            console.print(Panel(f"[bold]{title}[/bold]\n{message}", border_style="blue"))
            return
        
        if icon_path is None:
            icon_path = os.path.join(os.getcwd(), "icon.ico")
        if not os.path.exists(icon_path):
            icon_path = None
        
        self.toaster.show_toast(title, message, icon_path, duration, threaded)


# ============================================================================
# CLASSE C3POGeminiAssistant (Original mantida)
# ============================================================================
class C3POGeminiAssistant:
    """Assistente original C3PO com Gemini"""
    
    def __init__(self):
        pygame.mixer.init()
        self.voice_enabled = True
    
    def generate_gemini_response(self, prompt: str):
        """Gera uma resposta usando o modelo Gemini"""
        console.print("[yellow]⚠️  Gemini API não configurada[/yellow]")
        pass
    
    def execute_sql_query(self, query: str):
        """Executa uma consulta SQL"""
        console.print("[yellow]⚠️  SQL não configurado[/yellow]")
        pass
    
    def display_data(self, data: list[dict]):
        """Exibe os dados em uma tabela"""
        if not data:
            console.print("[yellow]Sem dados para exibir[/yellow]")
            return
        
        table = Table(title="Dados", box=box.ROUNDED)
        if data:
            for key in data[0].keys():
                table.add_column(key, style="cyan")
            for row in data:
                table.add_row(*[str(v) for v in row.values()])
        console.print(table)
    
    def falar(self, texto: str):
        """Gera e executa um áudio em português (voz sintética) - ORIGINAL"""
        console.print(f"[blue]🔊 {texto}[/blue]")
        
        if not self.voice_enabled or not gTTS:
            return
        
        try:
            tts = gTTS(text=texto, lang='pt-br', slow=False)
            arquivo = os.path.join(os.getcwd(), "fala_temp.mp3")
            tts.save(arquivo)
            
            # Reproduzir com pygame
            pygame.mixer.music.load(arquivo)
            pygame.mixer.music.play()
            
            # Aguardar finalizar
            while pygame.mixer.music.get_busy():
                time.sleep(0.1)
            
            os.remove(arquivo)
            
        except FileNotFoundError:
            console.print("[yellow]⚠️  Erro: 'mpg123' não encontrado[/yellow]")
        except Exception as e:
            console.print(f"[yellow]Erro ao gerar fala: {e}[/yellow]")
    
    def abrir_programa(self, nome_programa):
        """Abre o programa digitando no menu iniciar - ORIGINAL"""
        self.falar(f"Abrindo programa {nome_programa}")
        pyautogui.press('win')
        time.sleep(1)
        pyautogui.write(nome_programa)
        time.sleep(1)
        pyautogui.press('enter')
        time.sleep(5)
        console.print(f"[green]✅ {nome_programa} aberto.[/green]")


# ============================================================================
# CLASSE AnaRedeDeckBuilder (Original mantida e expandida)
# ============================================================================
class AnaRedeDeckBuilder:
    """Classe original para automação do AnaREDE"""
    
    def __init__(self, assistant: C3POGeminiAssistant):
        self.assistant = assistant
        
        # Coordenadas (serão calibradas depois)
        self.coordenadas = {
            'menu_caso': (50, 35),
            'abrir_caso': (100, 70),
            'salvar_caso': (100, 95),
            'menu_exibir': (106, 35),
            'menu_dados': (165, 35),
            'menu_analise': (248, 35),
            'executar_fluxo': (300, 100),
        }
    
    def carregar_save_case(self, caminho_arquivo):
        """Carrega um arquivo .SAV no AnaREDE - ORIGINAL"""
        self.assistant.falar("Carregando caso do fluxo de potência.")
        time.sleep(2)
        
        # Simulação de cliques (ajustar coordenadas conforme tela)
        pyautogui.click(x=100, y=50)  # menu principal (Arquivo)
        time.sleep(1)
        pyautogui.click(x=120, y=150)  # opção "Abrir Caso"
        time.sleep(2)
        
        # Digita o caminho do arquivo e pressiona Enter
        pyautogui.write(caminho_arquivo)
        pyautogui.press('enter')
        time.sleep(3)
        
        console.print(f"[green]✅ Caso {os.path.basename(caminho_arquivo)} carregado no AnaREDE.[/green]")
    
    def abrirEditCepel(self):
        """Abre o menu Edit -> Cepel - ORIGINAL"""
        self.assistant.abrir_programa("EditCepel")
    
    def carregar_diagrama(self, caminho_arquivo: str):
        """Carrega um arquivo de diagrama no Organon - ORIGINAL"""
        self.assistant.falar("Carregando diagrama elétrico no Organon.")
        time.sleep(2)
        
        pyautogui.click(x=100, y=50)  # menu principal
        time.sleep(1)
        pyautogui.click(x=130, y=180)  # opção "Abrir Diagrama"
        time.sleep(2)
        pyautogui.write(caminho_arquivo)
        pyautogui.press('enter')
        time.sleep(3)
        
        console.print(f"[green]✅ Diagrama {os.path.basename(caminho_arquivo)} carregado no Organon.[/green]")
    
    def diagnosticar_posicao_mouse(self):
        """Mostra a posição atual do mouse e emite um alerta - ORIGINAL"""
        self.assistant.falar("Diagnóstico da posição do mouse ativado. Mova o mouse para o local desejado.")
        time.sleep(3)
        x, y = pyautogui.position()
        self.assistant.falar(f"Posição do mouse: X={x}, Y={y}")
        console.print(f"[green]Posição do mouse: X={x}, Y={y}[/green]")
        
        # Alerta visual (opcional)
        pyautogui.alert(text=f'Posição do mouse: X={x}, Y={y}', 
                       title='Diagnóstico de Posição', button='OK')
    
    def executar_fluxo(self):
        """Executa cálculo de fluxo de potência"""
        self.assistant.falar("Executando cálculo de fluxo")
        pyautogui.press('f5')
        time.sleep(3)
        console.print("[green]✅ Fluxo executado[/green]")


# ============================================================================
# CLASSE MouseTracker (Nova - para rastreamento avançado)
# ============================================================================
class MouseTracker:
    """Rastreador avançado de posição do mouse"""
    
    def __init__(self):
        self.tracking = False
        self.positions = []
    
    def start_tracking(self, duration: int = 10):
        """Inicia rastreamento por um período definido"""
        self.tracking = True
        console.print(f"\n[yellow]🖱️  Rastreamento ativado por {duration} segundos[/yellow]")
        console.print("[cyan]Pressione ESC para parar[/cyan]\n")
        
        start_time = time.time()
        
        try:
            import keyboard
            while self.tracking and (time.time() - start_time) < duration:
                if keyboard.is_pressed('esc'):
                    break
                
                x, y = pyautogui.position()
                timestamp = time.time() - start_time
                
                console.print(f"\r[green]Posição: X={x:4d}, Y={y:4d}[/green] | Tempo: {timestamp:.1f}s", end="")
                
                self.positions.append((x, y, timestamp))
                time.sleep(0.1)
        
        except ImportError:
            console.print("[yellow]⚠️  keyboard não instalado, usando modo simples[/yellow]")
            # Modo simples sem keyboard
            while self.tracking and (time.time() - start_time) < duration:
                x, y = pyautogui.position()
                timestamp = time.time() - start_time
                console.print(f"\r[green]Posição: X={x:4d}, Y={y:4d}[/green] | Tempo: {timestamp:.1f}s", end="")
                self.positions.append((x, y, timestamp))
                time.sleep(0.1)
        
        except KeyboardInterrupt:
            pass
        finally:
            self.tracking = False
            console.print("\n\n[yellow]Rastreamento finalizado[/yellow]")
            self.show_summary()
    
    def show_summary(self):
        """Mostra resumo das posições capturadas"""
        if not self.positions:
            console.print("[red]Nenhuma posição capturada[/red]")
            return
        
        table = Table(title="📍 Posições Capturadas", box=box.ROUNDED)
        table.add_column("#", style="cyan", justify="right")
        table.add_column("X", style="green", justify="right")
        table.add_column("Y", style="green", justify="right")
        table.add_column("Tempo (s)", style="yellow", justify="right")
        
        for i, (x, y, t) in enumerate(self.positions[-10:], 1):
            table.add_row(str(i), str(x), str(y), f"{t:.2f}")
        
        console.print(table)
    
    def capture_position(self, label: str = ""):
        """Captura posição atual com label"""
        x, y = pyautogui.position()
        console.print(f"[green]✓[/green] {label}: X={x}, Y={y}")
        return (x, y)


# ============================================================================
# CLASSE FileExplorer (Nova - explorador de arquivos Rich)
# ============================================================================
class FileExplorer:
    """Explorador de arquivos com Rich"""
    
    def __init__(self, base_path: str):
        self.base_path = Path(base_path)
    
    def listar_diretorio(self, caminho: Optional[Path] = None) -> List[Path]:
        """Lista arquivos de um diretório"""
        if caminho is None:
            caminho = self.base_path
        
        try:
            items = sorted(caminho.iterdir(), key=lambda x: (not x.is_dir(), x.name))
            return items
        except Exception as e:
            console.print(f"[red]Erro ao listar: {e}[/red]")
            return []
    
    def mostrar_tree(self, caminho: Optional[Path] = None, max_depth: int = 2):
        """Mostra árvore de diretórios"""
        if caminho is None:
            caminho = self.base_path
        
        tree = Tree(f"📁 [bold cyan]{caminho.name}[/bold cyan]")
        self._build_tree(tree, caminho, 0, max_depth)
        console.print(tree)
    
    def _build_tree(self, tree, path: Path, depth: int, max_depth: int):
        """Constrói árvore recursivamente"""
        if depth >= max_depth:
            return
        
        try:
            items = sorted(path.iterdir(), key=lambda x: (not x.is_dir(), x.name))
            
            for item in items:
                if item.name.startswith('.'):
                    continue
                
                if item.is_dir():
                    branch = tree.add(f"📁 [cyan]{item.name}[/cyan]")
                    self._build_tree(branch, item, depth + 1, max_depth)
                else:
                    icon = self._get_file_icon(item.suffix)
                    tree.add(f"{icon} [green]{item.name}[/green]")
        except PermissionError:
            tree.add("[red]⛔ Acesso negado[/red]")
    
    def _get_file_icon(self, extensao: str) -> str:
        """Retorna ícone baseado na extensão"""
        icons = {
            '.py': '🐍',
            '.sav': '💾',
            '.lst': '📋',
            '.pwf': '⚡',
            '.dat': '📊',
            '.xlsx': '📈',
            '.csv': '📉'
        }
        return icons.get(extensao.lower(), '📄')
    
    def mostrar_tabela(self, caminho: Optional[Path] = None):
        """Mostra arquivos em tabela"""
        if caminho is None:
            caminho = self.base_path
        
        items = self.listar_diretorio(caminho)
        
        table = Table(title=f"📂 {caminho}", box=box.ROUNDED)
        table.add_column("#", style="cyan", justify="right")
        table.add_column("Tipo", style="blue")
        table.add_column("Nome", style="green")
        table.add_column("Tamanho", style="yellow", justify="right")
        
        for i, item in enumerate(items, 1):
            tipo = "📁 DIR" if item.is_dir() else self._get_file_icon(item.suffix) + " FILE"
            nome = item.name
            
            if item.is_file():
                tamanho = self._format_size(item.stat().st_size)
            else:
                tamanho = "-"
            
            table.add_row(str(i), tipo, nome, tamanho)
        
        console.print(table)
        return items
    
    def _format_size(self, size: int) -> str:
        """Formata tamanho de arquivo"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} TB"


# ============================================================================
# CLASSE EditCepelAutomation (Nova - atalhos EditCepel)
# ============================================================================
class EditCepelAutomation:
    """Automação específica para EditCepel"""
    
    ATALHOS = {
        'novo': 'ctrl+n',
        'abrir': 'ctrl+o',
        'regua': 'ctrl+*',
        'colar': 'ctrl+v',
        'salvar': 'ctrl+s',
        'fechar': 'ctrl+w'
    }
    
    def __init__(self, assistente: C3POGeminiAssistant):
        self.assistente = assistente
    
    def abrir_arquivo(self, caminho: str, delay: float = 2.0):
        """Abre arquivo PWF ou DAT no EditCepel"""
        self.assistente.falar("Abrindo arquivo no EditCepel")
        
        pyautogui.hotkey('ctrl', 'o')
        time.sleep(delay)
        
        pyautogui.write(caminho, interval=0.05)
        time.sleep(0.5)
        
        pyautogui.press('enter')
        time.sleep(delay)
        
        console.print(f"[green]✓ Arquivo aberto: {Path(caminho).name}[/green]")
    
    def inserir_regua(self):
        """Insere régua de comandos"""
        self.assistente.falar("Inserindo régua de comandos")
        pyautogui.hotkey('ctrl', 'shift', '8')  # ctrl+*
        time.sleep(0.5)
        console.print("[green]✓ Régua inserida[/green]")
    
    def mostrar_atalhos(self):
        """Exibe tabela de atalhos"""
        table = Table(title="⌨️  Atalhos EditCepel", box=box.ROUNDED)
        table.add_column("Ação", style="cyan")
        table.add_column("Atalho", style="yellow")
        
        for acao, atalho in self.ATALHOS.items():
            table.add_row(acao.title(), atalho)
        
        console.print(table)


# ============================================================================
# CLASSE CLIMenu (Integração com CLI Launcher)
# ============================================================================
class CLIMenu:
    """Menu CLI integrado com launcher"""
    
    def __init__(self, config: Configuracoes, assistant: C3POGeminiAssistant):
        self.config = config
        self.assistant = assistant
        self.deck_builder = AnaRedeDeckBuilder(assistant)
        self.mouse_tracker = MouseTracker()
        self.editcepel = EditCepelAutomation(assistant)
        
        # Explorador de arquivos
        self.explorer = FileExplorer(config.caminho_decks_anaRede)
        
        # Casos selecionados
        self.casos_selecionados = {
            'sav': None,
            'diagrama': None,
            'deck': None
        }
    
    def display_header(self):
        """Display welcome header"""
        console.clear()
        banner = """
        ╔═══════════════════════════════════════════════╗
        ║   ⚡ AUTOMAÇÃO SEP - AnaREDE & Organon      ║
        ║   Sistema Elétrico de Potência - ONS         ║
        ║   Integrado com CLI Launcher                 ║
        ╚═══════════════════════════════════════════════╝
        """
        console.print(Panel(banner, style="bold blue"))
    
    def display_menu(self) -> Optional[str]:
        """Display menu principal"""
        menu = Table(box=box.ROUNDED)
        menu.add_column("Opção", style="cyan", justify="center")
        menu.add_column("Descrição", style="white")
        
        opcoes = [
            ("1", "📂 Explorar arquivos (Tree)"),
            ("2", "📋 Selecionar casos/diagramas"),
            ("3", "▶️  Executar automação AnaREDE (anaRedeScript)"),
            ("4", "▶️  Executar automação Organon (OrganonScript)"),
            ("5", "🔄 Executar workflow completo (run_automation)"),
            ("6", "⌨️  Atalhos EditCepel"),
            ("7", "🖱️  Rastrear posição do mouse"),
            ("8", "📍 Diagnosticar posição do mouse (original)"),
            ("9", "🔊 Toggle voz"),
            ("0", "🚪 Sair")
        ]
        
        for num, desc in opcoes:
            menu.add_row(num, desc)
        
        console.print(menu)
        
        escolha = Prompt.ask(
            "\n[bold yellow]Escolha uma opção[/bold yellow]",
            choices=[o[0] for o in opcoes]
        )
        
        return escolha
    
    def explorar_arquivos(self):
        """Explora estrutura de arquivos"""
        console.clear()
        console.print("[bold cyan]📂 Estrutura de Diretórios[/bold cyan]\n")
        
        self.explorer.mostrar_tree(max_depth=3)
        
        if Confirm.ask("\nMostrar detalhes em tabela?"):
            console.print()
            self.explorer.mostrar_tabela()
        
        Prompt.ask("\n[dim]Pressione Enter para voltar[/dim]")
    
    def selecionar_casos(self):
        """Seleção interativa de casos"""
        console.clear()
        console.print("[bold cyan]📋 Seleção de Casos/Diagramas[/bold cyan]\n")
        
        base = Path(self.config.caminho_decks_anaRede)
        
        dirs = {
            'sav': base / 'Sav',
            'diagrama': base / 'diagramas',
            'deck': base / 'decks'
        }
        
        for tipo, dir_path in dirs.items():
            if not dir_path.exists():
                console.print(f"[yellow]⚠️  Diretório {tipo} não encontrado: {dir_path}[/yellow]")
                continue
            
            console.print(f"\n[cyan]═══ {tipo.upper()} ═══[/cyan]")
            items = self.explorer.mostrar_tabela(dir_path)
            
            if items:
                idx = Prompt.ask(
                    f"Selecione {tipo} (número) ou [dim]Enter para pular[/dim]",
                    default=""
                )
                
                if idx.isdigit():
                    idx = int(idx) - 1
                    if 0 <= idx < len(items):
                        self.casos_selecionados[tipo] = items[idx]
                        console.print(f"[green]✓ Selecionado: {items[idx].name}[/green]")
        
        # Mostrar resumo
        console.print("\n[bold]📊 Casos Selecionados:[/bold]")
        for tipo, arquivo in self.casos_selecionados.items():
            if arquivo:
                console.print(f"  {tipo}: [green]{arquivo.name}[/green]")
            else:
                console.print(f"  {tipo}: [dim]não selecionado[/dim]")
        
        Prompt.ask("\n[dim]Pressione Enter para voltar[/dim]")
    
    def menu_loop(self):
        """Loop principal do menu"""
        while True:
            self.display_header()
            escolha = self.display_menu()
            
            if escolha == "1":
                self.explorar_arquivos()
            
            elif escolha == "2":
                self.selecionar_casos()
            
            elif escolha == "3":
                self.executar_anarede_script()
            
            elif escolha == "4":
                self.executar_organon_script()
            
            elif escolha == "5":
                self.run_automation()
            
            elif escolha == "6":
                self.editcepel.mostrar_atalhos()
                Prompt.ask("\n[dim]Pressione Enter para continuar[/dim]")
            
            elif escolha == "7":
                duracao = int(Prompt.ask("Duração do rastreamento (segundos)", default="10"))
                self.mouse_tracker.start_tracking(duration=duracao)
                Prompt.ask("\n[dim]Pressione Enter para continuar[/dim]")
            
            elif escolha == "8":
                self.deck_builder.diagnosticar_posicao_mouse()
                Prompt.ask("\n[dim]Pressione Enter para continuar[/dim]")
            
            elif escolha == "9":
                self.assistant.voice_enabled = not self.assistant.voice_enabled
                status = "ativada" if self.assistant.voice_enabled else "desativada"
                console.print(f"[yellow]Voz {status}[/yellow]")
                time.sleep(1)
            
            elif escolha == "0":
                if Confirm.ask("Deseja realmente sair?"):
                    console.print("[yellow]Até logo! ⚡[/yellow]")
                    break
    
    def executar_anarede_script(self):
        """Executa anaRedeScript original"""
        console.clear()
        console.print("[bold cyan]⚡ Executando anaRedeScript[/bold cyan]\n")
        
        if not self.casos_selecionados['sav']:
            console.print("[red]❌ Nenhum arquivo .SAV selecionado![/red]")
            console.print("[yellow]Use a opção 2 para selecionar um caso[/yellow]")
            Prompt.ask("[dim]Pressione Enter[/dim]")
            return
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
            task = progress.add_task("Iniciando...", total=3)
            
            progress.update(task, description="Abrindo AnaREDE...")
            anaRedeScript(self.assistant, self.deck_builder, self.casos_selecionados)
            progress.advance(task)
        
        console.print("\n[green]✅ anaRedeScript concluído![/green]")
        Prompt.ask("[dim]Pressione Enter[/dim]")
    
    def executar_organon_script(self):
        """Executa OrganonScript original"""
        console.clear()
        console.print("[bold cyan]📊 Executando OrganonScript[/bold cyan]\n")
        
        if not self.casos_selecionados['diagrama']:
            console.print("[red]❌ Nenhum diagrama selecionado![/red]")
            console.print("[yellow]Use a opção 2 para selecionar um diagrama[/yellow]")
            Prompt.ask("[dim]Pressione Enter[/dim]")
            return
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
            task = progress.add_task("Iniciando...", total=2)
            
            progress.update(task, description="Abrindo Organon...")
            OrganonScript(self.assistant, self.deck_builder, self.casos_selecionados)
            progress.advance(task)
        
        console.print("\n[green]✅ OrganonScript concluído![/green]")
        Prompt.ask("[dim]Pressione Enter[/dim]")
    
    def run_automation(self):
        """Executa run_automation original completo"""
        console.clear()
        console.print("[bold cyan]🔄 Executando Workflow Completo[/bold cyan]\n")
        
        run_automation(self.assistant, self.deck_builder, self.casos_selecionados)
        
        console.print("\n[green]✅ Workflow completo finalizado![/green]")
        Prompt.ask("[dim]Pressione Enter[/dim]")


# ============================================================================
# FUNÇÕES ORIGINAIS (mantidas exatamente como estavam)
# ============================================================================

def anaRedeScript(assistant: C3POGeminiAssistant, deck_builder: AnaRedeDeckBuilder, 
                  casos: dict):
    """Script original de automação AnaREDE"""
    console.print("[green]🟢 Iniciando script de automação AnaREDE...[/green]")
    
    assistant.abrir_programa("Anarede 12")
    
    if casos['sav']:
        deck_builder.carregar_save_case(str(casos['sav']))
    else:
        console.print("[yellow]⚠️  Nenhum caso .SAV selecionado[/yellow]")


def OrganonScript(assistant: C3POGeminiAssistant, deck_builder: AnaRedeDeckBuilder,
                  casos: dict):
    """Script original de automação Organon"""
    console.print("[green]🟢 Iniciando script de automação Organon...[/green]")
    
    assistant.abrir_programa("Organon")
    
    if casos['diagrama']:
        deck_builder.carregar_diagrama(str(casos['diagrama']))
    else:
        console.print("[yellow]⚠️  Nenhum diagrama selecionado[/yellow]")


def run_automation(assistant: C3POGeminiAssistant, deck_builder: AnaRedeDeckBuilder,
                   casos: dict):
    """Rotina principal original - workflow completo"""
    assistant.falar("Iniciando rotina automática AnaREDE e Organon para análise do caso RSE.")
    
    anaRedeScript(assistant, deck_builder, casos)
    
    # Opcional: adicionar OrganonScript aqui se necessário
    # OrganonScript(assistant, deck_builder, casos)
    
    assistant.falar("Rotina finalizada com sucesso.")
    console.print("[green]✅ Automação concluída.[/green]")


# ============================================================================
# FUNÇÃO MAIN
# ============================================================================

def main():
    """Função principal - inicialização do sistema"""
    try:
        # Banner inicial
        console.print("\n[bold green]Iniciando Sistema de Automação SEP...[/bold green]\n")
        
        # Inicializar componentes
        config = Configuracoes()
        assistant = C3POGeminiAssistant()
        
        # Verificar caminho base
        base_path = Path(config.caminho_decks_anaRede)
        if not base_path.exists():
            console.print(f"[red]❌ Caminho não encontrado: {base_path}[/red]")
            console.print("[yellow]Ajuste o caminho_decks_anaRede na classe Configuracoes[/yellow]")
            return
        
        console.print(f"[cyan]Caminho base: {base_path}[/cyan]")
        console.print("[green]✓ Sistema pronto![/green]\n")
        
        time.sleep(2)
        
        # Iniciar CLI
        cli = CLIMenu(config, assistant)
        cli.menu_loop()
    
    except KeyboardInterrupt:
        console.print("\n[yellow]Programa interrompido pelo usuário[/yellow]")
    
    except Exception as e:
        console.print(f"\n[red]Erro fatal: {e}[/red]")
        import traceback
        console.print(traceback.format_exc())


if __name__ == "__main__":
    main()
